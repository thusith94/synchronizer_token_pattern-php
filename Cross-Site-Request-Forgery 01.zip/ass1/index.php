<!DOCTYPE html>
<html>
	<head>
		<title>Cross Site Request Forgery Protection</title>
	</head>
	<body>
		<form action="result.php" method="post">
			<div class="login">
				<strong>Login</strong>
					<div class="credentials">
							Username: <input type="text" name="username">
							Password: <input type="password" name="password">
					</div>
					<input type="Submit" value="Login">
					
			</div>
		</form>
	</body> 
</html>

